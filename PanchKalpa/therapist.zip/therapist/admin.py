from django.contrib import admin
from .models import Therapist, Therapy

admin.site.register(Therapist)
admin.site.register(Therapy)
